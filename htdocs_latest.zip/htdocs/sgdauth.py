from flask import Flask, render_template, request, redirect, url_for
from flask import session, flash
from flask import jsonify
import os
from functools import wraps
import MySQLdb
from flask.ext.hashing import Hashing

#create app object
app = Flask(__name__)

#hashing lines from hello3
#bcrypt = Bcrypt(app)
hashgun = Hashing(app)
# config
app.secret_key = os.urandom(11)

#Open db connection

db = MySQLdb.connect("localhost","root","password","py")

#prepare cursor object
cursor = db.cursor()

#execute SQL query
cursor.execute("SELECT VERSION()")

#Fetch table using fetchall() method
data = cursor.fetchall()

print "Database version: %s " % data
print "Database connection successful!"

#sgd packet class from hello3
class sgdPacket():
	def __init__(self, name, NFCtag):
		self.name = name
		self.NFCtag = NFCtag

#Route to HTML form in python

@app.route('/')
def form():
	return render_template('homepage.html')

@app.route('/register_load', methods=['POST','GET'])
def register_load():
	return render_template('register.html')
	
@app.route('/register', methods=['POST','GET'])
def register():
	reguser = request.form['reguser']
	regpass = request.form['regpass']
	cursor = db.cursor()
	regpass_hash = hashgun.hash_value(regpass)
	sqlreg = "INSERT INTO user (username, password) values ('%s', '%s')" % (reguser, regpass_hash)
	cursor.execute(sqlreg)
	db.commit()
	return render_template('homepage.html')
	
@app.route('/login_load', methods=['POST','GET'])
def login_load():
	return render_template('login.html')

#######################################################################
@app.route('/login', methods=['POST','GET'])
def login():
	error = None
	loguser = request.form['loguser']
	logpass = request.form['logpass']
	logpass_hash = hashgun.hash_value(logpass)
	cursor = db.cursor()
	sqllog = "SELECT * from user where username='" + loguser + "' and password='" + logpass_hash + "'"
	cursor.execute(sqllog)
	data = cursor.fetchone()
	if data is None:
		return "Username or Password is invalid."
	else:
		session['logged_in'] = True
		flash('Successfully logged in.')
		return render_template('homepage.html')

@app.route('/logout', methods=['POST','GET'])
def logout():
	session.pop('logged_in', None)
	flash('Successfully logged out.')
	return render_template('login.html')
	
# login required decorator
def login_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:
            flash('You need to login first.')
            return redirect(url_for('login'))
    return wrap
@login_required

@app.route('/welcome',methods = ['POST','GET']) #add post and get methods to make sure
def welcome():

	table = [] 

	table.append(sgdPacket("bob","qwe123qwe123qwe"))
	table.append(sgdPacket("jillard","345ert345ert345"))
	table.append(sgdPacket("dickling","uio789uio789uio"))
	test = 1
	nameid = request.form.get("name2")
	print nameid

	for i in range(len(table)-1,10):
		table.append(sgdPacket(None, None))

	# for i in range(0,len(results)):
	# 	table.append(results[i])

	# for i in range(len(results)-1, 10):
	# 	table.append(" ")

	return render_template("database3.html", table=table, length=len(table),test = test)
###################################################################
	
@app.route('/DeviceAuthorization_load', methods=['POST','GET'])
def DeviceAuthorization_load():
	return render_template('DeviceAuthorization.html')

#Route to submit form data in database and display it in browser

@app.route('/DeviceAuthorization', methods=['POST','GET'])
def DeviceAuthorization():
	user = request.form['UserName']
	sgd = request.form['sgd_ID']
	cursor = db.cursor()
	radio_btn_val = request.form['authorization']
	if radio_btn_val == 'authorize':
		sqli = "INSERT INTO sgdauth (UserName, sgd_ID) values ('%s', '%s')" % (user, sgd)
		cursor.execute(sqli)
	if radio_btn_val == 'unauthorize':
		sqli = "DELETE FROM sgdauth WHERE UserName=%s AND sgd_ID=%s"
		cursor.execute(sqli, (user,sgd,))
	db.commit()
	cursor=db.cursor()
	sqls = "SELECT * FROM sgdauth"
	cursor.execute(sqls)
	db_data = cursor.fetchall()
	tbl = "<table style='border:1px solid blue'>"
	for row in db_data:
		tbl = tbl + "<tr>"
		for data in row:
			tbl = tbl + "<td>" + str(data) + "</td>"
		tbl = tbl + "</tr>"
	return "<html><body>" + tbl + "</body></html>"
	
@app.route('/postmethod', methods = ['POST','GET'])
def get_post_key():
	jsdata=request.form['key']
	return render_template('authorization.html')
	
if __name__ == "__main__":
	app.run(debug=True)