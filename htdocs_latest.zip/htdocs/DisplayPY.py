for row in db_data:
		print row[2], row[1], row[0]