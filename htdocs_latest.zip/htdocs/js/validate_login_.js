function validateForm()
{
	var a = document.forms["loginform"]["email"].value;
	if(a==null || x=="")
	{
		alert("The email field is required.")
		return false;
	}
}