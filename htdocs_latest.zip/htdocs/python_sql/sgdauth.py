from flask import Flask, render_template, request, redirect, url_for
import MySQLdb
from flaskext.mysql import MySQL
sgdauth = Flask(__name__)

mysql=MySQL()
sgdauth.config['MYSQL_DATABASE_USER'] = 'root'
sgdauth.config['MYSQL_DATABASE_PASSWORD'] = 'password'
sgdauth.config['MYSQL_DATABASE_DB'] = 'py'
sgdauth.config['MYSQL_DATABASE_HOST'] = 'localhost'
mysql.init_app(sgdauth)

@sgdauth.route('/DeviceAuthorization.html', methods=['GET'])
def DeviceAuthorization():
	user = request.form['UserName']
	sgd = request.form['sgd_ID']
	dbconn = mysql.connect()
	cursor = dbconn.cursor()
	sqli = "INSERT INTO sgdauth (UserName, sgd_ID) values ('%s', '%s')" % (user, sgd)
	cursor.execute(sqli)
	dbconn.commit()
	return redirect(url_for('displaysgdauth.py'))
if __name__ == "__DeviceAuthorization__":
	sgdauth.run()