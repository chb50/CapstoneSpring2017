import mysql.connector as dbconn
import cgi, cgitb

def htmlContent():
	print("""Content-type:text/html\n\n
			<!DOCTYPE html>
			<html lang="en">
			<head>
				<meta charset="utf-8"/>
				<title> SGD Authorization </title>
				</head>
				<body>""")
def htmlEnd():
	print("""</body>
		</html>""")
def connection():
	db = dbconn.connect(host='localhost', user='root',passwd='password',db='py')
	cursor = db.cursor()
	return db, cursor

def selectAuth(db,cursor):
	sqli = "select * from sgdauth"
	cursor.execute(sqli)
	sgd = cursor.fetchall()
	return sgd

def displaySGD(sgd):
	print("<table border='2'>")
	print("<tr>")
	print("<th>ID</th>")
	print("<th>UserName</th>")
	print("<th>sgd_id</th>")
	print("</tr>")
	for each in sgd:
		print("<tr>")
		print("<td>{0}</td>" .format(each[0]))
		print("<td>{0}</td>" .format(each[1]))
		print("<td>{0}</td>" .format(each[2]))
		print("</tr>")
	print("</table>")

if __name__ == "__main__":
	try:
		htmlContent()
		db, cursor = connection()
		sgd = selectAuth(db,cursor)
		cursor.close()
		displaySGD(sgd)
		htmlEnd()
	except:
		cgi.print_exception()