#!/usr/bin/python

import MySQLdb

#Open db connection

db = MySQLdb.connect("localhost","root","password","py")

#prepare cursor object
cursor = db.cursor()

#execute SQL query
cursor.execute("SELECT VERSION()")

#Fetch table using fetchall() method
data = cursor.fetchall()

print "Database version: %s " % data
print "Databse connection successful!"

#disconnect from server
db.close()